<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Books List</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .card {
            margin-bottom: 20px;
            border: none;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 20px;
        }
        .card-title {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .card-text {
            margin-bottom: 5px;
        }
        .image-container {
            margin-top: 20px;
        }
        .book-image {
            max-width: 200px;
            height: auto;
        }
        .btn-add{
            text-align: center;
            margin: 20px;
        }
        .btn-primary{
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">Books List</h1>
        <div class="btn-add">
            <a href="<?php echo e(route('addBooks')); ?>" class="btn btn-success">Add Books</a>
        </div>

        <form action="<?php echo e(route('searchBooks')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="category">Search by title :</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <input type="submit" href="" class="btn btn-primary" value="Filter">
        </form>

        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title"><?php echo e($book->title); ?></h2>
                    <div class="image-container">
                        <img src="<?php echo e($book->url); ?>" alt="<?php echo e($book->title); ?>" class="book-image">
                    </div>
                    <p class="card-text"><strong>Description:</strong> <?php echo e($book->description); ?></p>
                    <p class="card-text"><strong>Price:</strong> $<?php echo e($book->price); ?></p>
                    <p class="card-text"><strong>Category:</strong> <?php echo e($book->category); ?></p>
                    <div class="btn-group">
                        <a href="/books/update/<?php echo e($book->book_id); ?>" class="btn btn-warning">Update</a>
                        <form action="/books/delete/<?php echo e($book->book_id); ?>" method="POST">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <input type="submit" href="" class="btn btn-danger" value="Delete">
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($books->links('pagination::bootstrap-4')); ?>


        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back to Home</a>
    </div>
</body>
</html>
<?php /**PATH C:\Users\theo\Documents\PostTraining\Laravel-Day3\Gramedia\gramedia\resources\views/viewbooks.blade.php ENDPATH**/ ?>